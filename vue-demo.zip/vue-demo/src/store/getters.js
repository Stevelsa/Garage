const getters={
    user:state=>state.user.user
}

export default getters