<template>
    <div>
        <SearchBar></SearchBar>
    </div>
</template>

<script>
import SearchBar from '@/components/SearchBar/index.vue'

export default {
    components:{
        SearchBar
    }    
}
</script>