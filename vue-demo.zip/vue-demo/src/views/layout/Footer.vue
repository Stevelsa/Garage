<template>
    <div class="footer">
        <div>推荐使用谷歌浏览器或Internet Explorer 11， 1024*768 及以上分辨率</div>
        <div>2016–2021 © 豆瓣 All Rights Reserved.</div>
    </div>
</template>

<script>
export default {
    name: 'FooterInfo'
}
</script>