package com.dtt.forum.forumserver.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dtt.forum.forumserver.bean.User;
import com.dtt.forum.forumserver.mapper.UserMapper;

@Service
@Transactional
public class UserService implements UserDetailsService{
	@Autowired
	UserMapper userMapper;
	
	

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user=userMapper.loadUserByUsername(username);
		if(user==null){
			return new User();
		}
		return user;
	}

}
