package com.dtt.forum.forumserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;

@SpringBootApplication(exclude = {SecurityAutoConfiguration.class})
public class ForumserverApplication {
	public static void main(String[] args) {
		SpringApplication.run(ForumserverApplication.class, args);
	}
}
