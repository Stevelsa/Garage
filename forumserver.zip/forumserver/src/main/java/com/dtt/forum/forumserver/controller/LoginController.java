package com.dtt.forum.forumserver.controller;

import com.dtt.forum.forumserver.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dtt.forum.forumserver.bean.RespBean;

@RestController
public class LoginController {

	@Autowired
	UserService userService;

	@RequestMapping("/login")
	public RespBean loginS(){
		System.out.println("err");
		return new RespBean("success", "登录成功");
	}

	@RequestMapping("/")
	public RespBean login(){
		return new RespBean("success", "登录成功");
	}

	@RequestMapping("/login_error")
	public RespBean loginError() {
		return new RespBean("error", "登录失败!");
	}

	@RequestMapping("/login_success")
	public RespBean loginSuccess() {
		return new RespBean("success", "登录成功!");
	}
}
